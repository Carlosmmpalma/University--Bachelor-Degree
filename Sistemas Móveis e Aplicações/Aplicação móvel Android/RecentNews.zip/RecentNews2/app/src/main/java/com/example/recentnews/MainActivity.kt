package com.example.recentnews

import android.app.ProgressDialog
import android.content.Intent
import android.os.Bundle
import android.view.WindowManager
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.auth.FirebaseAuthInvalidCredentialsException
import com.google.firebase.auth.FirebaseAuthInvalidUserException
import com.google.firebase.auth.FirebaseUser
import com.google.firebase.messaging.FirebaseMessaging

class MainActivity : AppCompatActivity() {
    private lateinit var createnewAccount: TextView
    private var inputEmail: EditText? = null
    private var inputPassword: EditText? = null
    private var emailPattern = Regex("^[_A-Za-z0-9-\\+]+(\\.[_A-Za-z0-9-]+)*@"
            + "[A-Za-z0-9-]+(\\.[A-Za-z0-9]+)*(\\.[A-Za-z]{2,})$")
    private var progressDialog: ProgressDialog? = null
    private var mAuth: FirebaseAuth? = null
    private var mUser: FirebaseUser? = null
    private lateinit var btnLogin: Button

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.login)

        FirebaseMessaging.getInstance().subscribeToTopic("News")
            .addOnCompleteListener { task ->
                var msg = "Done"
                if (!task.isSuccessful) {
                    msg = "Failed"
                }
            }


        createnewAccount = findViewById(R.id.noacc)
        window.setFlags(
            WindowManager.LayoutParams.FLAG_FULLSCREEN,
            WindowManager.LayoutParams.FLAG_FULLSCREEN
        )

        inputEmail = findViewById(R.id.email)
        inputPassword = findViewById(R.id.password)
        btnLogin = findViewById(R.id.acc)
        progressDialog = ProgressDialog(this)
        mAuth = FirebaseAuth.getInstance()
        mUser = mAuth!!.currentUser

        createnewAccount.setOnClickListener {
            startActivity(
                Intent(
                    this@MainActivity,
                    RegisterActivity::class.java
                )
            )
        }

        btnLogin.setOnClickListener { perforLogin() }
    }

    private fun perforLogin() {
        val email = inputEmail!!.text.toString()
        val password = inputPassword!!.text.toString()
        if (!email.matches(emailPattern)) {
            inputEmail!!.error = "Enter a correct email!"
        } else if (password.isEmpty() || password.length < 6) {
            inputPassword!!.error = "Enter a proper password!"
        } else {
            progressDialog!!.setMessage("Please Wait While Login")
            progressDialog!!.setTitle("Login")
            progressDialog!!.setCanceledOnTouchOutside(false)
            progressDialog!!.show()
            mAuth!!.signInWithEmailAndPassword(email, password).addOnCompleteListener { task ->
                if (task.isSuccessful) {
                    progressDialog!!.dismiss()
                    sendUserToNextActivity()
                    Toast.makeText(this@MainActivity, "Login bem sucedido", Toast.LENGTH_LONG)
                        .show()
                } else {
                    progressDialog!!.dismiss()
                    val exception = task.exception
                    if (exception is FirebaseAuthInvalidUserException) {
                        // Usuário não existe
                        Toast.makeText(
                            this@MainActivity,
                            "Conta não encontrada. Verifique o email digitado.",
                            Toast.LENGTH_LONG
                        ).show()
                    } else if (exception is FirebaseAuthInvalidCredentialsException) {
                        // Senha incorreta
                        Toast.makeText(
                            this@MainActivity,
                            "Senha incorreta. Verifique a senha digitada.",
                            Toast.LENGTH_LONG
                        ).show()
                    } else {
                        // Outro erro
                        Toast.makeText(
                            this@MainActivity,
                            "Erro ao fazer login: " + exception!!.message,
                            Toast.LENGTH_LONG
                        ).show()
                    }
                }
            }
        }
    }

    private fun sendUserToNextActivity() {
        val intent = Intent(this@MainActivity, HomeActivity::class.java)
        intent.flags = Intent.FLAG_ACTIVITY_CLEAR_TASK or Intent.FLAG_ACTIVITY_NEW_TASK
        startActivity(intent)
    }
}