package com.example.recentnews

import android.content.Intent
import android.os.Bundle
import android.util.Log
import android.widget.AdapterView.OnItemClickListener
import android.widget.ArrayAdapter
import android.widget.ImageView
import android.widget.ListView
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.GravityCompat
import androidx.drawerlayout.widget.DrawerLayout
import com.google.firebase.FirebaseApp
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.Query

class HomeActivity : AppCompatActivity() {
    private lateinit var btnMenu: ImageView
    private lateinit var drawerLayout: DrawerLayout
    private lateinit var goHome: TextView
    private lateinit var recentNews: TextView
    private lateinit var search: TextView
    private lateinit var newsId1: String
    private lateinit var newsId2: String
    private lateinit var newsId3: String

    public override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        FirebaseApp.initializeApp(this)
        val db = FirebaseFirestore.getInstance()
        val newsRef = db.collection("Noticias")

        setContentView(R.layout.activity_home)
        btnMenu = findViewById(R.id.menu_icon)
        drawerLayout = findViewById(R.id.drawer_layout)
        goHome = findViewById(R.id.home)
        recentNews = findViewById(R.id.recentnews)
        search = findViewById(R.id.search)

        goHome.setOnClickListener {
            startActivity(
                Intent(
                    this@HomeActivity,
                    HomeActivity::class.java
                )
            )
        }

        recentNews.setOnClickListener {
            startActivity(
                Intent(
                    this@HomeActivity,
                    NewsActivity::class.java
                )
            )
        }

        search.setOnClickListener {
            startActivity(
                Intent(
                    this@HomeActivity,
                    SearchActivity::class.java
                )
            )
        }

        // Array para armazenar os IDs dos documentos
        val recentIds: MutableList<String> = ArrayList()

        // Consulta para obter os documentos em ordem decrescente por data de criação
        val query = newsRef.orderBy("Data", Query.Direction.DESCENDING).limit(3)

        // Executa a consulta
        query.get().addOnSuccessListener { queryDocumentSnapshots ->
            // Loop pelos documentos da consulta
            for (documentSnapshot in queryDocumentSnapshots) {
                // Obtém o ID do documento e adiciona ao array
                recentIds.add(documentSnapshot.id)
            }

            // Os três IDs mais recentes estão no array recentIds
            Log.d("TAG", "IDs mais recentes: $recentIds")
            if (recentIds.size > 0) {
                newsId1 = recentIds[0]
                newsId2 = recentIds[1]
                newsId3 = recentIds[2]
                newsRef.document(newsId1).get().addOnSuccessListener { documentSnapshot ->
                    if (documentSnapshot.exists()) {
                        val title = documentSnapshot.getString("Titulo")
                        val description = documentSnapshot.getString("Conteudo")
                        documentSnapshot.getTimestamp("Data")
                        val textViewFeaturedNewsTitle1 =
                            findViewById<TextView>(R.id.textViewFeaturedNewsTitle1)
                        textViewFeaturedNewsTitle1.text = title
                        val textViewFeaturedNewsContent1 =
                            findViewById<TextView>(R.id.textViewFeaturedNewsContent1)
                        textViewFeaturedNewsContent1.text = description
                    } else {
                        Log.d("TAG", "A notícia$newsId1 não foi encontrada")
                    }
                }.addOnFailureListener { e -> // Ocorreu um erro ao buscar a notícia
                    Log.e("TAG", "Erro ao procurar a notícia", e)
                }
                newsRef.document(newsId2).get().addOnSuccessListener { documentSnapshot ->
                    if (documentSnapshot.exists()) {
                        val title = documentSnapshot.getString("Titulo")
                        val description = documentSnapshot.getString("Conteudo")
                        documentSnapshot.getTimestamp("Data")
                        val textViewFeaturedNewsTitle2 =
                            findViewById<TextView>(R.id.textViewFeaturedNewsTitle2)
                        textViewFeaturedNewsTitle2.text = title
                        val textViewFeaturedNewsContent2 =
                            findViewById<TextView>(R.id.textViewFeaturedNewsContent2)
                        textViewFeaturedNewsContent2.text = description
                    } else {
                        Log.d("TAG", "A notícia$newsId2 não foi encontrada")
                    }
                }.addOnFailureListener { e -> // Ocorreu um erro ao buscar a notícia
                    Log.e("TAG", "Erro ao procurar a notícia", e)
                }
                newsRef.document(newsId3).get().addOnSuccessListener { documentSnapshot ->
                    if (documentSnapshot.exists()) {
                        val title = documentSnapshot.getString("Titulo")
                        val description = documentSnapshot.getString("Conteudo")
                        documentSnapshot.getTimestamp("Data")
                        val textViewFeaturedNewsTitle3 =
                            findViewById<TextView>(R.id.textViewFeaturedNewsTitle3)
                        textViewFeaturedNewsTitle3.text = title
                        val textViewFeaturedNewsContent3 =
                            findViewById<TextView>(R.id.textViewFeaturedNewsContent3)
                        textViewFeaturedNewsContent3.text = description
                    } else {
                        Log.d("TAG", "A notícia$newsId3 não foi encontrada")
                    }
                }.addOnFailureListener { e -> // Ocorreu um erro ao buscar a notícia
                    Log.e("TAG", "Erro ao procurar a notícia", e)
                }
            }
        }.addOnFailureListener { e -> // Ocorreu um erro ao obter os IDs mais recentes
            Log.e("TAG", "Erro ao obter os IDs mais recentes", e)
        }


        // Items do menu
        val menuItemsArray =
            arrayOf("Desporto", "Cultura", "Tecnologia", "Economia", "Política", "", "Logout")

        // ListView do drawer
        val drawerList = findViewById<ListView>(R.id.drawer_list)

        //Adaptador ArrayAdapter<String> para o ListView do drawer
        val drawerAdapter = ArrayAdapter(
            this,
            android.R.layout.simple_list_item_1,  // layout de item simples fornecido pelo Android
            menuItemsArray
        )

        // Adaptador para o ListView do drawer
        drawerList.adapter = drawerAdapter
        drawerList.onItemClickListener =
            OnItemClickListener { _, _, position, _ -> // Lógica para lidar com o clique nos items do menu
                when (position) {
                    0 -> exibirNoticias("Desporto")
                    1 -> exibirNoticias("Cultura")
                    2 -> exibirNoticias("Tecnologia")
                    3 -> exibirNoticias("Economia")
                    4 -> exibirNoticias("Politica")
                    5 -> {}
                    6 -> {
                        val intent = Intent(this@HomeActivity, MainActivity::class.java)
                        startActivity(intent)
                    }
                }
                drawerLayout.closeDrawer(GravityCompat.START)
            }
        btnMenu.setOnClickListener { drawerLayout.openDrawer(GravityCompat.START) }
    }

    private fun exibirNoticias(categoria: String) {
        val intent = Intent(this@HomeActivity, NewsPerType::class.java)
        intent.putExtra("categoria", categoria)
        startActivity(intent)
    }
}