package com.example.recentnews

import android.app.ProgressDialog
import android.content.Intent
import android.os.Bundle
import android.view.View
import android.view.WindowManager
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.auth.FirebaseAuthUserCollisionException
import com.google.firebase.auth.FirebaseUser

class RegisterActivity : AppCompatActivity() {
    private lateinit var alreadyHaveAccount: TextView
    private var inputEmail: EditText? = null
    private var inputPassword: EditText? = null
    private lateinit var btnRegister: Button
    private var emailPattern = Regex("^[_A-Za-z0-9-\\+]+(\\.[_A-Za-z0-9-]+)*@"
            + "[A-Za-z0-9-]+(\\.[A-Za-z0-9]+)*(\\.[A-Za-z]{2,})$")
    private var progressDialog: ProgressDialog? = null
    private var mAuth: FirebaseAuth? = null
    private var mUser: FirebaseUser? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.register)

        window.setFlags(
            WindowManager.LayoutParams.FLAG_FULLSCREEN,
            WindowManager.LayoutParams.FLAG_FULLSCREEN
        )

        alreadyHaveAccount = findViewById(R.id.btn_login)
        inputEmail = findViewById(R.id.email)
        inputPassword = findViewById(R.id.password)
        btnRegister = findViewById(R.id.btn_register)
        progressDialog = ProgressDialog(this)
        mAuth = FirebaseAuth.getInstance()
        mUser = mAuth!!.currentUser
        alreadyHaveAccount.setOnClickListener {
            startActivity(
                Intent(
                    this@RegisterActivity,
                    MainActivity::class.java
                )
            )
        }
        btnRegister.setOnClickListener { perforAuth() }
    }

    private fun perforAuth() {
        val email = inputEmail!!.text.toString()
        val password = inputPassword!!.text.toString()
        if (!email.matches(emailPattern)) {
            inputEmail!!.error = "Enter a correct email!"
        } else if (password.isEmpty() || password.length < 6) {
            inputPassword!!.error = "Enter a proper password!"
        } else {
            progressDialog!!.setMessage("Please Wait While Registration")
            progressDialog!!.setTitle("Registration")
            progressDialog!!.setCanceledOnTouchOutside(false)
            progressDialog!!.show()
            mAuth!!.createUserWithEmailAndPassword(email, password).addOnCompleteListener { task ->
                if (task.isSuccessful) {
                    progressDialog!!.dismiss()
                    sendUserToNextActivity()
                    Toast.makeText(
                        this@RegisterActivity,
                        "Registration Successful",
                        Toast.LENGTH_LONG
                    ).show()
                } else {
                    progressDialog!!.dismiss()
                    val exception = task.exception
                    if (exception is FirebaseAuthUserCollisionException) {
                        // Email já está em uso
                        Toast.makeText(
                            this@RegisterActivity,
                            "O email fornecido já está em uso. Tente com um email diferente.",
                            Toast.LENGTH_LONG
                        ).show()
                    } else {
                        // Outro erro
                        Toast.makeText(
                            this@RegisterActivity,
                            "Erro ao registrar: " + exception!!.message,
                            Toast.LENGTH_LONG
                        ).show()
                    }
                }
            }
        }
    }

    private fun sendUserToNextActivity() {
        val intent = Intent(this@RegisterActivity, MainActivity::class.java)
        intent.flags = Intent.FLAG_ACTIVITY_CLEAR_TASK or Intent.FLAG_ACTIVITY_NEW_TASK
        startActivity(intent)
    }
}