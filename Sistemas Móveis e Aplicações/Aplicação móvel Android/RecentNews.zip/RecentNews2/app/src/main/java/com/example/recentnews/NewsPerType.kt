package com.example.recentnews

import android.content.ContentValues
import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.util.Log
import android.widget.AdapterView.OnItemClickListener
import android.widget.ArrayAdapter
import android.widget.ImageView
import android.widget.ListView
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.GravityCompat
import androidx.drawerlayout.widget.DrawerLayout
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.google.firebase.FirebaseApp
import com.google.firebase.firestore.FirebaseFirestore

class NewsPerType : AppCompatActivity() {
    private lateinit var goHome: TextView
    private lateinit var recentNews: TextView
    private lateinit var news_title: TextView
    private lateinit var search: TextView
    private lateinit var btnMenu: ImageView
    private lateinit var drawerLayout: DrawerLayout
    private var category: String? = null
    private lateinit var recyclerView: RecyclerView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_news_per_type)
        FirebaseApp.initializeApp(this)
        val db = FirebaseFirestore.getInstance()
        val newsRef = db.collection("Noticias")
        category = intent.getStringExtra("categoria")
        btnMenu = findViewById(R.id.menu_icon)
        drawerLayout = findViewById(R.id.drawer_layout)
        goHome = findViewById(R.id.home)
        recentNews = findViewById(R.id.recentnews)
        news_title = findViewById(R.id.textViewFeaturedNewsTitle)
        recyclerView = findViewById(R.id.mRecyclerView)
        search = findViewById(R.id.search)

        goHome.setOnClickListener {
            startActivity(
                Intent(
                    this@NewsPerType,
                    HomeActivity::class.java
                )
            )
        }
        recentNews.setOnClickListener {
            startActivity(
                Intent(
                    this@NewsPerType,
                    NewsActivity::class.java
                )
            )
        }
        search.setOnClickListener {
            startActivity(
                Intent(
                    this@NewsPerType,
                    SearchActivity::class.java
                )
            )
        }

        //Noticias da categoria escolhida
        news_title.text = "Notícias de $category:"

        // Array para armazenar as Noticias
        val newsList: MutableList<News> = ArrayList()
        val context: Context = this
        newsRef.whereEqualTo("Tipo", category)
            .get()
            .addOnCompleteListener { task ->
                if (task.isSuccessful) {
                    for (document in task.result) {
                        // Obter os dados da notícia
                        val titulo = document.getString("Titulo")
                        val descricao = document.getString("Conteudo")

                        // Criar objeto News com os dados recuperados
                        val news = News(titulo!!, descricao!!)
                        newsList.add(news)
                    }
                    val adapter = News_RecyclerViewAdapter(context, newsList)
                    recyclerView.adapter = adapter
                    recyclerView.layoutManager = LinearLayoutManager(context)
                } else {
                    Log.d(ContentValues.TAG, "Erro ao obter notícias por tipo: ", task.exception)
                }
            }


        // Items do menu
        val menuItemsArray =
            arrayOf("Desporto", "Cultura", "Tecnologia", "Economia", "Política", "", "Logout")

        // ListView do drawer
        val drawerList = findViewById<ListView>(R.id.drawer_list)

        //Adaptador ArrayAdapter<String> para o ListView do drawer
        val drawerAdapter = ArrayAdapter(
            this,
            android.R.layout.simple_list_item_1,  // layout de item simples fornecido pelo Android
            menuItemsArray
        )

        // Adaptador para o ListView do drawer
        drawerList.adapter = drawerAdapter
        drawerList.onItemClickListener =
            OnItemClickListener { _, _, position, _ -> // Lógica para lidar com o clique nos items do menu
                when (position) {
                    0 -> exibirNoticias("Desporto")
                    1 -> exibirNoticias("Cultura")
                    2 -> exibirNoticias("Tecnologia")
                    3 -> exibirNoticias("Economia")
                    4 -> exibirNoticias("Politica")
                    5 -> {}
                    6 -> {
                        val intent = Intent(this@NewsPerType, MainActivity::class.java)
                        startActivity(intent)
                    }
                }
                drawerLayout.closeDrawer(GravityCompat.START)
            }
        btnMenu.setOnClickListener { drawerLayout.openDrawer(GravityCompat.START) }
    }

    private fun exibirNoticias(categoria: String) {
        val intent = Intent(this@NewsPerType, NewsPerType::class.java)
        intent.putExtra("categoria", categoria)
        startActivity(intent)
    }
}