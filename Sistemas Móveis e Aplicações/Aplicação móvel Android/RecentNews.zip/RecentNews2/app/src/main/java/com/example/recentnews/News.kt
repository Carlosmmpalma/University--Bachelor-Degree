package com.example.recentnews

class News(val title: String, val description: String)