package com.example.recentnews

import android.content.Context
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import com.example.recentnews.News_RecyclerViewAdapter.MyViewHolder

class News_RecyclerViewAdapter(var context: Context, var noticias: List<News>) :
    RecyclerView.Adapter<MyViewHolder>() {
    private val filteredList: List<News>? = null

    fun setFilteredList(filteredList: List<News>) {
        noticias = filteredList
        notifyDataSetChanged()
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): MyViewHolder {
        //Aparencia de cada linha
        val inflater = LayoutInflater.from(context)
        val view = inflater.inflate(R.layout.recycler_view_row, parent, false)
        return MyViewHolder(view)
    }

    override fun onBindViewHolder(holder: MyViewHolder, position: Int) {
        //Dando valores a cada linha
        holder.title.text = noticias[position].title
        holder.description.text = noticias[position].description
    }

    override fun getItemCount(): Int {
        //Numero de items
        return noticias.size
    }

    class MyViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        var imageView: ImageView
        var title: TextView
        var description: TextView

        init {
            imageView = itemView.findViewById(R.id.image_view)
            title = itemView.findViewById(R.id.title_text_view)
            description = itemView.findViewById(R.id.description_text_view)
        }
    }
}